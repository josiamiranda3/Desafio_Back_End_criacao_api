from rest_framework.test import APITestCase
from .models import Profissional

class ProfissionalTests(APITestCase):
    def test_criar_profissional(self):
        data = {
            "nome_social": "Dra. Ana",
            "profissao": "Psicóloga",
            "endereco": "Rua X",
            "contato": "(11) 99999-9999"
        }
        response = self.client.post("/api/profissionais/", data)
        self.assertEqual(response.status_code, 201)